package com.example.pizzaapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    Pizza pizza;
    TextView total;
    double totalPrice;
    double toppingCost;
    private Spinner spinner;
    private static final String[] paths = {"Select Topping", "Mushroom($5)", "Sun Dried Tomatoes ($5)", "Chicken ($7)", "Ground Beef ($8)", "Shrimps ($10)", "Pineapple ($5)", "Steak ($9)", "Avocado ($5)", "Tuna ($5)", "Brocolli ($8)"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //creating references to interface widgets
        pizza = new Pizza();
        final EditText customerName = (EditText)findViewById(R.id.nameTxt);
        final EditText customerAddress= (EditText)findViewById(R.id.addressTxt);
        final EditText customerNumber= (EditText)findViewById(R.id.numberTxt);
        final EditText customerEmail= (EditText)findViewById(R.id.emailTxt);
        final Button calcBtn = (Button)findViewById(R.id.calcBtn);
         total = findViewById(R.id.total);

        spinner = findViewById(R.id.spinner);
        //create an adapter to describe how items are displayed
        ArrayAdapter<String> adapter = new ArrayAdapter<>(MainActivity.this, android.R.layout.simple_spinner_dropdown_item, paths);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);


        //create onClickListener
        calcBtn.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                //TODO Auto-generated method stub

                //read user input
                Intent myIntent = new Intent(MainActivity.this, MainActivity2.class);

                MainActivity.this.startActivity(myIntent);

                String nameOfCustomer = customerName.getText().toString();
                String addressOfCustomer = customerAddress.getText().toString();
                String numberOfCustomer = customerNumber.getText().toString();
                String emailOfCustomer = customerEmail.getText().toString();

                //display result
                String result = "Thank you for your order! \n Name: " + nameOfCustomer + " \nAddress: " + addressOfCustomer + " \nE-mail: " + emailOfCustomer + " \nPhone Number: " + numberOfCustomer + " \nOrder Total: " + calculate_total();
                total.setText(result);
            }
        });
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View v, int position, long id) {

        switch (position) {
            case 0:
                toppingCost = 0;
                break;
            case 1:
                toppingCost = 5.0;
                calculate_total();
                break;
            case 2:
                toppingCost = 5.0;
                calculate_total();
                break;
            case 3:
                toppingCost = 7.0;
                calculate_total();
                break;
            case 4:
                toppingCost = 8.0;
                calculate_total();
                break;
            case 5:
                toppingCost = 10.0;
                calculate_total();
                break;
            case 6:
                toppingCost = 5.0;
                calculate_total();
                break;
            case 7:
                toppingCost = 9.0;
                calculate_total();
                break;
            case 8:
                toppingCost = 5.0;
                calculate_total();
                break;
            case 9:
                toppingCost = 5.0;
                calculate_total();
                break;
            case 20:
                toppingCost = 8.0;
                calculate_total();
                break;

        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {
        // TODO Auto-generated method stub
    }

    public void radioClicked(View view) {

        //is the button now checked
        boolean checked = ((RadioButton) view).isChecked();
        //check which radio button was clicked
        switch(view.getId()){
            case R.id.rb1:
                if (checked)
                    pizza.setPizzaSizePrice(5.50);
                break;
            case R.id.rb2:
                if(checked)
                    pizza.setPizzaSizePrice(7.99);
                break;
            case R.id.rb3:
                if(checked)
                    pizza.setPizzaSizePrice(9.50);
                break;
            case R.id.rb4:
                if(checked)
                    pizza.setPizzaSizePrice(11.38);
                break;
        }
        total.setText("Total Price: " + pizza.getPizzaSizePrice());

    }

    public void onCheckboxClicked(View view) {
        //is the view now checked
        boolean checked = ((CheckBox) view).isChecked();

        //check which checkbox was clicked
        switch(view.getId()){
            case R.id.cb1:
                if(checked)
                    pizza.setExtraCheese(5);
                else
                    pizza.setExtraCheese(0);
                break;

            case R.id.cb2:
                if(checked)
                    pizza.setDeliveryPrice(5);
                else
                    pizza.setDeliveryPrice(0);
                break;
        }
        //total.setText("Total Price: " + calculate_total());

    }



    private double calculate_total()
    {
        totalPrice = pizza.getPizzaSizePrice() + pizza.getDeliveryPrice() + pizza.getExtraCheese() + toppingCost;
        return totalPrice;
    }

}
