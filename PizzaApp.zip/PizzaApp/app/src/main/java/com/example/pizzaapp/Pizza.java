package com.example.pizzaapp;

public class Pizza {

    double pizzaSizePrice;
    double extraCheesePrice = 0;
    double deliveryPrice = 0;
    double veggiePrice = 0;

    public Pizza() {
    }

    public double getPizzaSizePrice() {
        return pizzaSizePrice;
    }

    public void setPizzaSizePrice(double pizzaSizePrice) {
        this.pizzaSizePrice = pizzaSizePrice;
    }

    public double getExtraCheese() {
        return extraCheesePrice;
    }

    public void setExtraCheese(double meatPrice) {
        this.extraCheesePrice = meatPrice;
    }

    public double getDeliveryPrice() {
        return deliveryPrice;
    }

    public void setDeliveryPrice(double cheesePrice) {
        this.deliveryPrice = cheesePrice;
    }

    public double getVeggiePrice() {
        return veggiePrice;
    }

    public void setVeggiePrice(double veggiePrice) {
        this.veggiePrice = veggiePrice;
    }
}

