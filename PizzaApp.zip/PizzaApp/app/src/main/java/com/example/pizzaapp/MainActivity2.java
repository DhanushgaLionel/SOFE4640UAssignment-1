package com.example.pizzaapp;

class MainActivity2 {
super.onCreate(savedInstanceState);
    // Get the view from new_activity.xml
    setContentView(R.layout.new_activity);
}
